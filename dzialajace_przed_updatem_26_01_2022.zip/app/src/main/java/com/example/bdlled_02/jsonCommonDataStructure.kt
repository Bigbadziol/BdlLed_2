package com.example.bdlled_02

data class jColor(
    var r : Int = 0,
    var g : Int = 0,
    var b : Int = 0
)